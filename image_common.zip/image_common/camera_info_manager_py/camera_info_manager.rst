camera_info_manager
-------------------

.. automodule:: camera_info_manager
   :members:
