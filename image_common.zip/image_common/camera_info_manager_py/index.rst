camera_info_manager: ROS CameraInfo support for Python camera drivers
=====================================================================

Contents:

.. toctree::
   :maxdepth: 2

   README
   camera_info_manager
   CHANGELOG

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
